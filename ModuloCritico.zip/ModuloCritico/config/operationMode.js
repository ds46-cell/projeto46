module.exports = {
  operationMode: "REAL"
};
